﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TNS
{
    internal class Manager
    {
        public static int codVhoda = 1111;
        public static int CodVhoda
        {
            get { return codVhoda; }
            set { codVhoda = value; }
        }


    }
}
